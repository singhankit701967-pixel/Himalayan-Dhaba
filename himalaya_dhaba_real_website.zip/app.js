const $=id=>document.getElementById(id);
let selectedTable="";
document.querySelectorAll("[data-table]").forEach(b=>b.addEventListener("click",()=>{selectedTable=b.dataset.table;$("table_id").value=selectedTable;document.querySelectorAll("[data-table]").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");}));
$("bookingForm").addEventListener("submit",async e=>{
 e.preventDefault();
 if(!selectedTable){$("bookingMessage").textContent="Please select a table first.";return;}
 const payload={table_id:selectedTable,name:$("name").value.trim(),phone:$("phone").value.trim(),booking_date:$("date").value,booking_time:$("time").value,guests:Number($("guests").value),note:$("note").value.trim(),status:"pending"};
 if(!window.SUPABASE_URL){$("bookingMessage").textContent="Demo mode: database is not connected yet. The live connection will be added in Step 2.";return;}
 try{
  const r=await fetch(`${SUPABASE_URL}/rest/v1/bookings`,{method:"POST",headers:{"apikey":SUPABASE_ANON_KEY,"Authorization":`Bearer ${SUPABASE_ANON_KEY}`,"Content-Type":"application/json","Prefer":"return=minimal"},body:JSON.stringify(payload)});
  $("bookingMessage").textContent=r.ok?"Booking request sent successfully.":"Could not send booking request.";
 }catch(err){$("bookingMessage").textContent="Connection error. Please try again.";}
});
$("feedbackForm").addEventListener("submit",async e=>{e.preventDefault();$("feedbackMessage").textContent=window.SUPABASE_URL?"Feedback will be connected in the database setup step.":"Demo mode: feedback is not saved yet.";});
if("serviceWorker" in navigator) navigator.serviceWorker.register("service-worker.js").catch(()=>{});
