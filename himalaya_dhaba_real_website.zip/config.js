// Add ONLY the public Supabase project URL and publishable/anon key here.
// NEVER put a Supabase service-role key or password in this file.
window.SUPABASE_URL = "";
window.SUPABASE_ANON_KEY = "";
